<footer class="section footer noover">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4">
                        <h4 class="widget-title">Tentang Kami</h4>
                        <p>Info lebih lanjut kunjungi atau hubungi yang tertera di bawah ini:</p>
                        <div class="layanan-sistem">
                            <li><a target="_blank" rel="noopener" href="#">Phone: </a></li>
                            <li><a target="_blank" href="#">Email: </a></li>
                            <li><a target="_blank" href="#">Alamat: </a></li>
                            
                        </div>
                    </div><!-- end col -->

                    <div class="col-lg-4 col-md-4">
                        <div class="widget clearfix">
                            <h4 class="widget-title">Portal Informasi</h4>
                            <div class="portal-informasi">
                                <li><a href="https://uns.ac.id">Laman UNS</a></li>
                                <li><a href="https://risnov.uns.ac.id/">Laman RISNOV</a></li>
                                
                               
                            </div>
                        </div><!-- end widget -->
                    </div><!-- end col -->

                    <div class="col-lg-4 col-md-4">
                        <h4 class="widget-title">Lokasi</h4>
                        <div class="textwidget">
                            <p><iframe style="width:100%; height: 480px;"
                                    src="https://widgets.moovit.com/w/66345083B5CBDD8FE0530100007FE639/874784"
                                    frameborder="0"></iframe>
                            </p>
                        </div>
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- end container -->
        </footer><!-- end footer -->

        <div class="copyrights">
            <div class="container">
                <div class="clearfix">
                    <div class="pull-left">
                        <div class="cop-logo">
                            <a href="#"><img src="images/logo.png" alt=""></a>
                        </div>
                    </div>

                    <div class="pull-right">
                        <div class="footer-links">
                            <ul class="list-inline">
                                <li>&copy; Copyright 2022 | Riset Inovasi Dalam Angka</li>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div><!-- end container -->
        </div><!-- end copy -->
